//  AnimalSounds.swift
//  Kidz Games
//  Created by Student on 11/25/25.

import SwiftUI

struct AnimalSounds: View {
    @AppStorage("tapCount1") private var cowCounter = 0
    @AppStorage("tapCount2") private var dogCounter = 0
    @AppStorage("tapCount3") private var catCounter = 0
    @AppStorage("tapCount4") private var sheepCounter = 0
    
    let showGame: String
    var body: some View {
        VStack{
            Text(showGame)
                .font(.title)
        }
        .padding(.bottom, 100)
        
        VStack {
            HStack{
                Button(action: {
                    cowCounter += 1
                }) {
                    ZStack {
                        Image("CowPic")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 180, height: 180)
                            .clipped()
                        //Text("Cow")
                    }
                }
                .cornerRadius(50)
                
                Button(action: {
                    dogCounter += 1
                }) {
                    ZStack {
                        Image("DogPic")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 180, height: 180)
                            .clipped()
                        //Text("Dog")
                    }
                }
                .cornerRadius(50)
            }
            Spacer()
                .frame(height: 50)
            
            HStack {
                Button(action: {
                    catCounter += 1
                }) {
                    ZStack {
                        Image("CatPic")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 180, height: 180)
                            .clipped()
                        //Text("Cat")
                    }
                }
                .cornerRadius(50)
                
                Button(action: {
                    sheepCounter += 1
                }) {
                    ZStack {
                        Image("SheepPic")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 180, height: 180)
                            .clipped()
                        //Text("Sheep")
                    }
                }
                .cornerRadius(50)
            }
            VStack {
                Text("You have cliked on Cow \(cowCounter) times")
                Text("You have cliked on Dog \(dogCounter) times")
                Text("You have cliked on Cat \(catCounter) times")
                Text("You have cliked on Sheep \(sheepCounter) times")
            }
            .padding(20)
        }
    }
}

#Preview {
    AnimalSounds(showGame: "Game")
}
