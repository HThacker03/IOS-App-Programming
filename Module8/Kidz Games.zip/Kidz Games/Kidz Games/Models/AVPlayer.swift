//  AVPlayer.swift
//  Kidz Games
//  Created by Student on 12/16/25.

import Foundation
import AVFoundation
