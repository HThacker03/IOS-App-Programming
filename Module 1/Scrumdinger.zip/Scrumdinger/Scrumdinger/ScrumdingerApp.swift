//
//  ScrumdingerApp.swift
//  Scrumdinger
//
//  Created by Student on 11/6/25.
//

import SwiftUI

@main
struct ScrumdingerApp: App {
    var body: some Scene {
        WindowGroup {
            MeetingView()
        }
    }
}
