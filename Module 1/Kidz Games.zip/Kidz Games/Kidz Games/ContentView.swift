//
//  ContentView.swift
//  Kidz Games
//
//  Created by Student on 11/12/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Kidz Games!")
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
