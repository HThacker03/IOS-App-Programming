//
//  ContentView.swift
//  Kidz Games
//
//  Created by Student on 11/12/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(alignment: .leading) {
            Text("Kidz Games!")
                .font(.headline)
        }
        .padding(.top, 25)
        
        
        NavigationStack {
            NavigationLink (destination: AnimalSounds()) {
                Text("Animal Sounds")
                    .font(.headline)
                    .accessibilityAddTraits(.isHeader)
                    .foregroundColor(.black)
                    .padding(50)
                    .background(.brown)
                    .cornerRadius(25)
            }
            .padding()
            NavigationLink (destination: BubblePop()) {
                Text("Bubble Pop")
                    .font(.headline)
                    .accessibilityAddTraits(.isHeader)
                    .foregroundColor(.black)
                    .padding(50)
                    .background(.green)
                    .cornerRadius(25)
            }
            .padding()
            NavigationLink (destination: ColorMatching()) {
                Text("ColorMatching")
                    .font(.headline)
                    .accessibilityAddTraits(.isHeader)
                    .foregroundColor(.black)
                    .padding(50)
                    .background(.blue)
                    .cornerRadius(25)
            }
            .padding()
            NavigationLink (destination: MathGames()) {
                Text("Math Games")
                    .font(.headline)
                    .accessibilityAddTraits(.isHeader)
                    .foregroundColor(.black)
                    .padding(50)
                    .background(.red)
                    .cornerRadius(25)
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
