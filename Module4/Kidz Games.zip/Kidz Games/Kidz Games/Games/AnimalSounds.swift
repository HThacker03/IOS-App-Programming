//  AnimalSounds.swift
//  Kidz Games
//  Created by Student on 11/25/25.

import SwiftUI

struct AnimalSounds: View {
    let showGame: String
    var body: some View {
        Text(showGame)
    }
}

#Preview {
    AnimalSounds(showGame: "Game")
}
