//  ContentView.swift
//  Kidz Games
//  Created by Student on 11/12/25.

import SwiftUI

struct ContentView: View {
    let game1: String = "Animal Sounds"
    let game2: String = "Bubble Pop"
    let game3: String = "Color Matching"
    let game4: String = "Math Games"
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Kidz Games!")
                .font(.headline)
        }
        .padding(.top, 25)
        
        
        NavigationStack {
            NavigationLink (destination: AnimalSounds(showGame: game1)) {
                Text(game1)
                    .font(.headline)
                    .accessibilityAddTraits(.isHeader)
                    .foregroundColor(.black)
                    .padding(50)
                    .background(.brown)
                    .cornerRadius(25)
            }
            .padding()
            NavigationLink (destination: BubblePop(showGame: game2)) {
                Text(game2)
                    .font(.headline)
                    .accessibilityAddTraits(.isHeader)
                    .foregroundColor(.black)
                    .padding(50)
                    .background(.green)
                    .cornerRadius(25)
            }
            .padding()
            NavigationLink (destination: ColorMatching(showGame: game3)) {
                Text(game3)
                    .font(.headline)
                    .accessibilityAddTraits(.isHeader)
                    .foregroundColor(.black)
                    .padding(50)
                    .background(.blue)
                    .cornerRadius(25)
            }
            .padding()
            NavigationLink (destination: MathGames(showGame: game4)) {
                Text(game4)
                    .font(.headline)
                    .accessibilityAddTraits(.isHeader)
                    .foregroundColor(.black)
                    .padding(50)
                    .background(.red)
                    .cornerRadius(25)
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
