//  AnimalSounds.swift
//  Kidz Games
//  Created by Student on 11/25/25.

import SwiftUI

struct AnimalSounds: View {
    let showGame: String
    var body: some View {
        Text(showGame)
        
        VStack {
            HStack{
                Button(action: {}) {
                    ZStack {
                        Image("CowPic")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 200, height: 200)
                            .clipped()
                        Text("Cow")
                    }
                } .cornerRadius(50)
                
                Button(action: {}) {
                    ZStack {
                        Image("DogPic")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 200, height: 200)
                            .clipped()
                        Text("Dog")
                    }
                } .cornerRadius(50)
            }
            Spacer()
                .frame(height: 50)
            
            HStack {
                Button(action: {}) {
                    ZStack {
                        Image("CatPic")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 200, height: 200)
                            .clipped()
                        Text("Cat")
                    }
                } .cornerRadius(50)
                
                Button(action: {}) {
                    ZStack {
                        Image("SheepPic")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 200, height: 200)
                            .clipped()
                        Text("Sheep")
                    }
                } .cornerRadius(50)
            }
        }
    }
}

#Preview {
    AnimalSounds(showGame: "Game")
}
