//
//  CardView.swift
//  Kidz Games
//
//  Created by Student on 11/13/25.
//

import SwiftUI

struct CardView: View {
    var body: some View {
        VStack(alignment: .leading) {
            Text("Game")
                .font(.headline)
                .accessibilityAddTraits(.isHeader)
        }
        .padding(50)
        .background(.orange)
        .cornerRadius(25)
        //.frame(width: 300, height: 200)
    }
}

#Preview {
    CardView()
}
