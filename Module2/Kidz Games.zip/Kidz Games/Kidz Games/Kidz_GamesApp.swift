//
//  Kidz_GamesApp.swift
//  Kidz Games
//
//  Created by Student on 11/12/25.
//

import SwiftUI

@main
struct Kidz_GamesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
