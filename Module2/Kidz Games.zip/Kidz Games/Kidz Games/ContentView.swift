//
//  ContentView.swift
//  Kidz Games
//
//  Created by Student on 11/12/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(alignment: .leading) {
            Text("Kidz Games!")
                .font(.headline)
        }
        .padding()
        
        ScrollView{
            VStack(spacing: 50) {
                HStack(spacing: 50) {
                    CardView()
                    CardView()
                }
                HStack(spacing: 50) {
                    CardView()
                    CardView()
                }
            }
            
        }
    }
}

#Preview {
    ContentView()
}
