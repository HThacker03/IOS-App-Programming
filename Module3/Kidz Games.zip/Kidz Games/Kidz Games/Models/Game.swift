//  Game.swift
//  Kidz Games
//  Created by Student on 11/13/25.

import Foundation

struct Game: Identifiable {
    let id = UUID()
    let title: String
}
