//
//  ContentView.swift
//  Kidz Games
//
//  Created by Student on 11/12/25.
//

import SwiftUI

struct ContentView: View {
    let gameTitleList: [Game] = [
        Game(title: "Game1"),
        Game(title: "Game2"),
        Game(title: "Game3"),
        Game(title: "Game4")
        
    ]
    var body: some View {
        VStack(alignment: .leading) {
            Text("Kidz Games!")
                .font(.headline)
        }
        .padding()
        
        VStack {
            ForEach(gameTitleList) { game in
                CardView(data: game)
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
