//
//  ContentView.swift
//  Kidz Games
//
//  Created by Student on 11/12/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(alignment: .leading) {
            Text("Kidz Games!")
                .font(.headline)
        }
        .padding()
        
        
        NavigationStack {
            NavigationLink (destination: AnimalSounds()) {
                Text("Animal Sounds")
                    .font(.headline)
                    .accessibilityAddTraits(.isHeader)
                    .foregroundColor(.black)
                    .padding(50)
                    .background(.green)
                    .cornerRadius(25)
            }
            NavigationLink (destination: BubblePop()) {
                Text("Bubble Pop")
                    .font(.headline)
                    .accessibilityAddTraits(.isHeader)
                    .foregroundColor(.black)
                    .padding(50)
                    .background(.green)
                    .cornerRadius(25)
            }
            NavigationLink (destination: ColorMatching()) {
                Text("ColorMatching")
                    .font(.headline)
                    .accessibilityAddTraits(.isHeader)
                    .foregroundColor(.black)
                    .padding(50)
                    .background(.green)
                    .cornerRadius(25)
            }
            NavigationLink (destination: MathGames()) {
                Text("Math Games")
                    .font(.headline)
                    .accessibilityAddTraits(.isHeader)
                    .foregroundColor(.black)
                    .padding(50)
                    .background(.green)
                    .cornerRadius(25)
            }
        }
    }
}

#Preview {
    ContentView()
}
