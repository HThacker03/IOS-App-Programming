//  AnimalSounds.swift
//  Kidz Games
//  Created by Student on 11/25/25.

import SwiftUI

struct AnimalSounds: View {
    var body: some View {
        Text("Animal Sounds")
    }
}

#Preview {
    AnimalSounds()
}
