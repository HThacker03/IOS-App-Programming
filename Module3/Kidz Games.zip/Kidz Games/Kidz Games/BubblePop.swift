//
//  BubblePop.swift
//  Kidz Games
//
//  Created by Student on 11/25/25.
//

import SwiftUI

struct BubblePop: View {
    var body: some View {
        Text("Bubble Pop")
    }
}

#Preview {
    BubblePop()
}
