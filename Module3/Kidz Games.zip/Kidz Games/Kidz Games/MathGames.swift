//
//  MathGames.swift
//  Kidz Games
//
//  Created by Student on 11/25/25.
//

import SwiftUI

struct MathGames: View {
    var body: some View {
        Text("Math Games")
    }
}

#Preview {
    MathGames()
}
