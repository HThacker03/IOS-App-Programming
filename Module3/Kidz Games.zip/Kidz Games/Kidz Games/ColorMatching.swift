//
//  ColorMatching.swift
//  Kidz Games
//
//  Created by Student on 11/25/25.
//

import SwiftUI

struct ColorMatching: View {
    var body: some View {
        Text("ColorMatching")
    }
}

#Preview {
    ColorMatching()
}
