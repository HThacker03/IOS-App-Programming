//
//  CardView.swift
//  Kidz Games
//
//  Created by Student on 11/13/25.
//

import SwiftUI

struct CardView: View {
    let data: Game
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(data.title)
                .font(.headline)
                .accessibilityAddTraits(.isHeader)
        }
        .padding(50)
        .background(.green)
        .cornerRadius(25)
        //.frame(width: 300, height: 200)
    }
}

#Preview {
    CardView(data: Game(title: "hi"))
}
